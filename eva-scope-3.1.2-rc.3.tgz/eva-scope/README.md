# EVA Scope Helm adapter

This chart is an optional Kubernetes deployment adapter. The container images
remain usable with Docker Compose, ECS or another OCI-compatible runtime.
ClickHouse can either be installed as an optional dependency of this chart or
provided by the platform as an external service. The default remains external
so existing installations keep their database lifecycle unchanged.

## ClickHouse modes

| `clickhouse.enabled` | Database topology | Backend credentials |
| --- | --- | --- |
| `false` (default) | External or platform-managed ClickHouse | `secrets.existingSecret` key `clickhouse-password` |
| `true` | In-cluster Bitnami ClickHouse, one shard and one replica | Generated `admin-password` Secret, or `clickhouse.auth.existingSecret` |

When enabled, the Chart wires the Backend to the generated ClickHouse Service,
database, HTTP/HTTPS port and credential Secret automatically. It creates a
single-node instance with persistent storage for development, test and small
single-instance deployments. Configure storage class, capacity and resources
for the cluster; use an external ClickHouse topology for HA or large-scale
analytics.

When `clickhouse.auth.existingSecret` is set, its password key must be supplied
as `clickhouse.auth.existingSecretKey`. The Backend uses the same Secret/key.
The application Secret still provides `eva-app-client-secret` in both modes.

## Exposure modes

The chart selects its HTTPS topology with `ingress.enabled`.

| `ingress.enabled` | TLS termination | EVA Scope Proxy |
| --- | --- | --- |
| `false` (default) | Proxy | Listens on HTTP and HTTPS; redirects HTTP to HTTPS |
| `true` | Ingress | HTTP-only ClusterIP upstream; retains API routing and rate limits |

When Ingress is enabled, the chart creates a Traefik `Ingress` and a
`Middleware` that redirects HTTP to HTTPS, then forwards all paths to the
Proxy HTTP service. The proxy remains in the request path so its API rate
limits and long analysis-request timeouts remain active. Do not expose the
Backend or Frontend services directly through a separate Ingress.

Set `ingress.realIp.trustedCidrs` to the Pod or node CIDRs used by the Ingress
Controller. The HTTP-only Proxy then trusts `X-Forwarded-For` only from those
peers and applies its rate limits to the real client address. Leaving it empty
uses the Ingress peer address for rate limiting.

## TLS Secrets

In direct Proxy mode, create the TLS Secret named by `proxy.tls.secretName`
before installing. It must contain the standard `tls.crt` and `tls.key` keys.

In Ingress mode, configure `ingress.tls`:

- `create: false`: create the target TLS Secret through the platform's normal
  Secret-management workflow before installing.
- `create: true`: a Helm post-install/post-upgrade Job reads the certificate
  source and creates or updates the target TLS Secret. The Job runs again on
  Helm upgrade, which is the supported way to refresh a hostPath certificate.

`authType: hostPath` reads files from a node directory. On multi-node clusters,
every eligible node must have that directory, or `ingress.tls.job.nodeSelector`
or affinity must pin the Job to the correct node. `authType: secret` mounts an
existing source Secret; its keys must match `certFile` and `keyFile`.

The created Kubernetes TLS Secret always uses `tls.crt` and `tls.key`, even when
the source files use the Docker Compose names `fullchain.pem` and `privkey.pem`.

The credentials Secret named by `secrets.existingSecret` is always managed
separately for `eva-app-client-secret`. In external ClickHouse mode it must
also contain `clickhouse-password`; the chart never creates application
credentials.

## ECR image pull Secret

`imagePullSecrets` follows the EVA platform's hostPath credential policy by
default. A pre-install/pre-upgrade Job mounts `/home/eva/.aws`, obtains an ECR
token, and creates `<release>-secret-regcred`. Backend, Frontend and Proxy
then refer to that generated Docker registry Secret. A periodic CronJob renews
the token; the default schedule is every 10 hours.

`imagePullSecrets.secretName` is used only with `authType: secret`: it is the
source Secret that contains AWS credentials, not the generated Docker registry
Secret. With `authType: hostPath`, pin the Job through
`imagePullSecrets.cronjob.nodeSelector` or affinity when `/home/eva/.aws` is
not available on every node.

Set `ExistingSecret` to use a pull Secret managed outside this chart. The ECR
credential Job, CronJob and associated RBAC are omitted in that mode.
