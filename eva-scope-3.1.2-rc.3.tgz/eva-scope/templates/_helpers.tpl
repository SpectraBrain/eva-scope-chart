{{- define "eva-scope.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "eva-scope.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name (include "eva-scope.name" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{- define "eva-scope.labels" -}}
helm.sh/chart: {{ include "eva-scope.name" . }}-{{ .Chart.Version | replace "+" "_" }}
app.kubernetes.io/name: {{ include "eva-scope.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{- define "eva-scope.backendName" -}}
{{- printf "%s-backend" (include "eva-scope.fullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "eva-scope.frontendName" -}}
{{- printf "%s-frontend" (include "eva-scope.fullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "eva-scope.proxyName" -}}
{{- printf "%s-proxy" (include "eva-scope.fullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "eva-scope.ingressTlsSecretName" -}}
{{- default (printf "%s-tls" (include "eva-scope.fullname" .)) .Values.ingress.tls.secretName | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "eva-scope.tlsJobName" -}}
{{- printf "%s-tls-secret" (include "eva-scope.fullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "eva-scope.clickhouseFullname" -}}
{{- default (printf "%s-clickhouse" .Release.Name) .Values.clickhouse.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "eva-scope.clickhouseAuthSecretName" -}}
{{- if .Values.clickhouse.auth.existingSecret -}}
{{- tpl .Values.clickhouse.auth.existingSecret . | trim -}}
{{- else -}}
{{- include "eva-scope.clickhouseFullname" . -}}
{{- end -}}
{{- end -}}

{{- define "eva-scope.clickhouseAuthSecretKey" -}}
{{- if .Values.clickhouse.auth.existingSecret -}}
{{- required "clickhouse.auth.existingSecretKey is required when clickhouse.auth.existingSecret is set" .Values.clickhouse.auth.existingSecretKey -}}
{{- else -}}
admin-password
{{- end -}}
{{- end -}}

{{- define "eva-scope.imagePullSecret.name" -}}
{{- if .Values.imagePullSecrets.nameOverride -}}
{{- .Values.imagePullSecrets.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-secret-regcred" .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{- define "eva-scope.imagePullSecrets" -}}
{{- if .Values.imagePullSecrets.enabled -}}
{{- if .Values.imagePullSecrets.ExistingSecret -}}
- name: {{ .Values.imagePullSecrets.ExistingSecret }}
{{- else if .Values.imagePullSecrets.create -}}
- name: {{ include "eva-scope.imagePullSecret.name" . }}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "eva-scope.ecrCredentialRefreshName" -}}
{{- printf "%s-ecr-credentials" (include "eva-scope.ecrCredentialNamePrefix" .) -}}
{{- end -}}

{{- define "eva-scope.ecrCredentialInitialJobName" -}}
{{- printf "%s-ecr-credentials-initial" (include "eva-scope.ecrCredentialNamePrefix" .) -}}
{{- end -}}

{{- define "eva-scope.ecrCredentialCleanupJobName" -}}
{{- printf "%s-ecr-credentials-cleanup" (include "eva-scope.ecrCredentialNamePrefix" .) -}}
{{- end -}}

{{- define "eva-scope.ecrCredentialNamePrefix" -}}
{{- include "eva-scope.fullname" . | trunc 38 | trimSuffix "-" -}}
{{- end -}}

{{- define "eva-scope.ecrCredentialRefreshPodSpec" -}}
serviceAccountName: {{ include "eva-scope.ecrCredentialRefreshName" . }}
restartPolicy: OnFailure
{{- with .Values.imagePullSecrets.cronjob.nodeSelector }}
nodeSelector:
{{ toYaml . | nindent 2 }}
{{- end }}
{{- with .Values.imagePullSecrets.cronjob.tolerations }}
tolerations:
{{ toYaml . | nindent 2 }}
{{- end }}
{{- with .Values.imagePullSecrets.cronjob.affinity }}
affinity:
{{ toYaml . | nindent 2 }}
{{- end }}
initContainers:
  - name: ecr-token-generator
    image: {{ .Values.imagePullSecrets.cronjob.image | quote }}
    imagePullPolicy: IfNotPresent
    command: ["/bin/sh", "-ec"]
    args:
      - |
        umask 077
        aws ecr get-login-password --region {{ .Values.imagePullSecrets.region | quote }} > /tmp/shared/ecr-token
    {{- if eq .Values.imagePullSecrets.authType "secret" }}
    envFrom:
      - secretRef:
          name: {{ .Values.imagePullSecrets.secretName }}
    {{- end }}
    volumeMounts:
      - name: shared-data
        mountPath: /tmp/shared
      {{- if eq .Values.imagePullSecrets.authType "hostPath" }}
      - name: aws-credentials
        mountPath: /root/.aws
        readOnly: true
      {{- end }}
containers:
  - name: ecr-secret-generator
    image: {{ .Values.imagePullSecrets.cronjob.kubectlImage | quote }}
    imagePullPolicy: IfNotPresent
    command: ["/bin/sh", "-ec"]
    args:
      - |
        test -s /tmp/shared/ecr-token
        kubectl -n "$POD_NAMESPACE" create secret docker-registry "$TARGET_SECRET" \
          --docker-server="$ECR_REGISTRY" \
          --docker-username=AWS \
          --docker-password="$(cat /tmp/shared/ecr-token)" \
          --dry-run=client -o yaml \
          | kubectl -n "$POD_NAMESPACE" apply -f -
    env:
      - name: POD_NAMESPACE
        valueFrom:
          fieldRef:
            fieldPath: metadata.namespace
      - name: TARGET_SECRET
        value: {{ include "eva-scope.imagePullSecret.name" . | quote }}
      - name: ECR_REGISTRY
        value: {{ printf "%s.dkr.ecr.%s.amazonaws.com" .Values.imagePullSecrets.account .Values.imagePullSecrets.region | quote }}
    resources:
{{ toYaml .Values.imagePullSecrets.cronjob.resources | nindent 6 }}
    volumeMounts:
      - name: shared-data
        mountPath: /tmp/shared
volumes:
  - name: shared-data
    emptyDir: {}
{{- if eq .Values.imagePullSecrets.authType "hostPath" }}
  - name: aws-credentials
    hostPath:
      path: {{ .Values.imagePullSecrets.hostPath | quote }}
      type: Directory
{{- end }}
{{- end -}}
