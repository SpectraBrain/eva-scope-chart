# EVA Scope Helm adapter

This chart is an optional Kubernetes deployment adapter. The container images
remain usable with Docker Compose, ECS or another OCI-compatible runtime.

The chart expects an existing TLS Secret named by `proxy.tls.secretName` and an
existing credentials Secret named by `secrets.existingSecret`. It does not create
or store private keys and application credentials.
