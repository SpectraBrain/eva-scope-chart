{{- define "eva-scope.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "eva-scope.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name (include "eva-scope.name" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}

{{- define "eva-scope.labels" -}}
helm.sh/chart: {{ include "eva-scope.name" . }}-{{ .Chart.Version | replace "+" "_" }}
app.kubernetes.io/name: {{ include "eva-scope.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{- define "eva-scope.backendName" -}}
{{- printf "%s-backend" (include "eva-scope.fullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "eva-scope.frontendName" -}}
{{- printf "%s-frontend" (include "eva-scope.fullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "eva-scope.proxyName" -}}
{{- printf "%s-proxy" (include "eva-scope.fullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "eva-scope.ingressTlsSecretName" -}}
{{- default (printf "%s-tls" (include "eva-scope.fullname" .)) .Values.ingress.tls.secretName | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "eva-scope.tlsJobName" -}}
{{- printf "%s-tls-secret" (include "eva-scope.fullname" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "eva-scope.clickhouseFullname" -}}
{{- default (printf "%s-clickhouse" .Release.Name) .Values.clickhouse.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "eva-scope.clickhouseAuthSecretName" -}}
{{- if .Values.clickhouse.auth.existingSecret -}}
{{- tpl .Values.clickhouse.auth.existingSecret . | trim -}}
{{- else -}}
{{- include "eva-scope.clickhouseFullname" . -}}
{{- end -}}
{{- end -}}

{{- define "eva-scope.clickhouseAuthSecretKey" -}}
{{- if .Values.clickhouse.auth.existingSecret -}}
{{- required "clickhouse.auth.existingSecretKey is required when clickhouse.auth.existingSecret is set" .Values.clickhouse.auth.existingSecretKey -}}
{{- else -}}
admin-password
{{- end -}}
{{- end -}}
