# EVA Scope Helm adapter

This chart is an optional Kubernetes deployment adapter. The container images
remain usable with Docker Compose, ECS or another OCI-compatible runtime.
ClickHouse is external to this chart and must be installed or provided before
EVA Scope is installed.

## Exposure modes

The chart selects its HTTPS topology with `ingress.enabled`.

| `ingress.enabled` | TLS termination | EVA Scope Proxy |
| --- | --- | --- |
| `false` (default) | Proxy | Listens on HTTP and HTTPS; redirects HTTP to HTTPS |
| `true` | Ingress | HTTP-only ClusterIP upstream; retains API routing and rate limits |

When Ingress is enabled, the chart creates a Traefik `Ingress` and a
`Middleware` that redirects HTTP to HTTPS, then forwards all paths to the
Proxy HTTP service. The proxy remains in the request path so its API rate
limits and long analysis-request timeouts remain active. Do not expose the
Backend or Frontend services directly through a separate Ingress.

Set `ingress.realIp.trustedCidrs` to the Pod or node CIDRs used by the Ingress
Controller. The HTTP-only Proxy then trusts `X-Forwarded-For` only from those
peers and applies its rate limits to the real client address. Leaving it empty
uses the Ingress peer address for rate limiting.

## TLS Secrets

In direct Proxy mode, create the TLS Secret named by `proxy.tls.secretName`
before installing. It must contain the standard `tls.crt` and `tls.key` keys.

In Ingress mode, configure `ingress.tls`:

- `create: false`: create the target TLS Secret through the platform's normal
  Secret-management workflow before installing.
- `create: true`: a Helm post-install/post-upgrade Job reads the certificate
  source and creates or updates the target TLS Secret. The Job runs again on
  Helm upgrade, which is the supported way to refresh a hostPath certificate.

`authType: hostPath` reads files from a node directory. On multi-node clusters,
every eligible node must have that directory, or `ingress.tls.job.nodeSelector`
or affinity must pin the Job to the correct node. `authType: secret` mounts an
existing source Secret; its keys must match `certFile` and `keyFile`.

The created Kubernetes TLS Secret always uses `tls.crt` and `tls.key`, even when
the source files use the Docker Compose names `fullchain.pem` and `privkey.pem`.

The credentials Secret named by `secrets.existingSecret` is always managed
separately. It must contain at least `clickhouse-password` and
`eva-app-client-secret`; the chart never creates application credentials.
